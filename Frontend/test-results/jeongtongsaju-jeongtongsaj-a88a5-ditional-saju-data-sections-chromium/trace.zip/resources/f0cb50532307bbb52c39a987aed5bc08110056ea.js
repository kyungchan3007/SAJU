(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0d7a5f~._.js","static/chunks/node_modules_0m70snv._.js"],
    source: "dynamic"
});
