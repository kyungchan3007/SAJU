(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/features/saju-result/model/query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SAJU_RESULT_QUERY_KEY",
    ()=>SAJU_RESULT_QUERY_KEY
]);
const SAJU_RESULT_QUERY_KEY = [
    "saju-result"
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-result/hooks/useSajuResultGate.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSajuResultGate",
    ()=>useSajuResultGate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$model$2f$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-result/model/query.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
async function fetchSajuResult() {
    const response = await fetch("/api/saju/result", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        }
    });
    const result = await response.json();
    if (!response.ok) {
        throw new Error(result.success ? "Failed to fetch saju result." : result.error.message);
    }
    return result;
}
function useSajuResultGate() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const hasCachedResult = Boolean(queryClient.getQueryData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$model$2f$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAJU_RESULT_QUERY_KEY"]));
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!hasCachedResult);
    const [errorMessage, setErrorMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useSajuResultGate.useEffect": ()=>{
            let cancelled = false;
            if (hasCachedResult) {
                return;
            }
            const load = {
                "useSajuResultGate.useEffect.load": async ()=>{
                    try {
                        const result = await fetchSajuResult();
                        if (cancelled) {
                            return;
                        }
                        queryClient.setQueryData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$model$2f$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAJU_RESULT_QUERY_KEY"], result);
                        setIsLoading(false);
                    } catch (error) {
                        if (cancelled) {
                            return;
                        }
                        setErrorMessage(error instanceof Error ? error.message : "사주 결과를 불러오지 못했습니다.");
                        setIsLoading(false);
                    }
                }
            }["useSajuResultGate.useEffect.load"];
            void load();
            return ({
                "useSajuResultGate.useEffect": ()=>{
                    cancelled = true;
                }
            })["useSajuResultGate.useEffect"];
        }
    }["useSajuResultGate.useEffect"], [
        hasCachedResult,
        queryClient
    ]);
    return {
        isLoading,
        errorMessage
    };
}
_s(useSajuResultGate, "LVs+9CWnB3A1K/6VEW8kYQVWkiE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-result/ui/saju-result-query-gate.client.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SajuResultQueryGate",
    ()=>SajuResultQueryGate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$hooks$2f$useSajuResultGate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-result/hooks/useSajuResultGate.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function SajuResultQueryGate({ children }) {
    _s();
    const { isLoading, errorMessage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$hooks$2f$useSajuResultGate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuResultGate"])();
    if (isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "card-saju-primary p-6 text-sm text-black/60",
            children: "사주 결과를 불러오는 중입니다."
        }, void 0, false, {
            fileName: "[project]/src/features/saju-result/ui/saju-result-query-gate.client.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this);
    }
    if (errorMessage) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "card-saju-primary p-6 text-sm text-red-600",
            children: errorMessage
        }, void 0, false, {
            fileName: "[project]/src/features/saju-result/ui/saju-result-query-gate.client.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(SajuResultQueryGate, "jFL7yTOnqDqbCQicjxuSWr3ln6I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$hooks$2f$useSajuResultGate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuResultGate"]
    ];
});
_c = SajuResultQueryGate;
var _c;
__turbopack_context__.k.register(_c, "SajuResultQueryGate");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-result/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$model$2f$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-result/model/query.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$ui$2f$saju$2d$result$2d$query$2d$gate$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-result/ui/saju-result-query-gate.client.tsx [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/hooks/useSajuHooks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSajuHooks",
    ()=>useSajuHooks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/features/saju-result/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$model$2f$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-result/model/query.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const useSajuHooks = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const resultPath = "/saju/result";
    const handleSubmitSaju = async (formValues)=>{
        const response = await fetch("/api/saju/result", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formValues)
        });
        if (response.status === 401) {
            await fetch("/api/saju/draft", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(formValues)
            });
            router.push("/login?intent=saju_submit");
            return;
        }
        if (!response.ok) {
            return;
        }
        const result = await response.json();
        queryClient.setQueryData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$result$2f$model$2f$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAJU_RESULT_QUERY_KEY"], result);
        router.push(resultPath);
    };
    return {
        handleSubmitSaju
    };
};
_s(useSajuHooks, "GXsxXqkLNpg9rNSA2fykCwUUldE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/model/date-time-options/model.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BIRTH_TIME_OPTIONS",
    ()=>BIRTH_TIME_OPTIONS,
    "DAY_OPTIONS",
    ()=>DAY_OPTIONS,
    "HOUR_OPTIONS",
    ()=>HOUR_OPTIONS,
    "MINUTE_OPTIONS",
    ()=>MINUTE_OPTIONS,
    "MONTH_OPTIONS",
    ()=>MONTH_OPTIONS
]);
const HOUR_OPTIONS = Array.from({
    length: 24
}, (_, hour)=>{
    const ampm = hour < 12 ? "오전" : "오후";
    const hourLabel = hour === 0 ? "0시 (자시)" : hour <= 12 ? `${hour}시` : `${hour - 12}시`;
    return {
        value: String(hour),
        label: `${ampm} ${hourLabel}`
    };
});
const MINUTE_OPTIONS = Array.from({
    length: 60
}, (_, minute)=>({
        value: String(minute),
        label: `${String(minute).padStart(2, "0")}분`
    }));
const MONTH_OPTIONS = Array.from({
    length: 12
}, (_, monthIndex)=>({
        value: String(monthIndex + 1),
        label: `${monthIndex + 1}월`
    }));
const DAY_OPTIONS = Array.from({
    length: 31
}, (_, dayIndex)=>({
        value: String(dayIndex + 1),
        label: `${dayIndex + 1}일`
    }));
const BIRTH_TIME_OPTIONS = [
    {
        value: "",
        label: "시간 선택"
    },
    {
        value: "00:00",
        label: "오전 00:00 (자시)"
    },
    {
        value: "01:00",
        label: "오전 01:00"
    },
    {
        value: "02:00",
        label: "오전 02:00"
    },
    {
        value: "03:00",
        label: "오전 03:00"
    },
    {
        value: "04:00",
        label: "오전 04:00"
    },
    {
        value: "05:00",
        label: "오전 05:00"
    },
    {
        value: "06:00",
        label: "오전 06:00"
    },
    {
        value: "07:00",
        label: "오전 07:00"
    },
    {
        value: "08:00",
        label: "오전 08:00"
    },
    {
        value: "09:00",
        label: "오전 09:00"
    },
    {
        value: "09:30",
        label: "오전 09:30"
    },
    {
        value: "10:00",
        label: "오전 10:00"
    },
    {
        value: "11:00",
        label: "오전 11:00"
    },
    {
        value: "12:00",
        label: "오후 12:00"
    },
    {
        value: "13:00",
        label: "오후 01:00"
    },
    {
        value: "14:00",
        label: "오후 02:00"
    },
    {
        value: "15:00",
        label: "오후 03:00"
    },
    {
        value: "16:00",
        label: "오후 04:00"
    },
    {
        value: "17:00",
        label: "오후 05:00"
    },
    {
        value: "18:00",
        label: "오후 06:00"
    },
    {
        value: "19:00",
        label: "오후 07:00"
    },
    {
        value: "20:00",
        label: "오후 08:00"
    },
    {
        value: "21:00",
        label: "오후 09:00"
    },
    {
        value: "22:00",
        label: "오후 10:00"
    },
    {
        value: "23:00",
        label: "오후 11:00"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/model/city-options/model.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CITY_OPTIONS",
    ()=>CITY_OPTIONS
]);
const CITY_OPTIONS = [
    {
        value: "",
        label: "출생 도시 선택"
    },
    {
        value: "서울특별시",
        label: "서울특별시"
    },
    {
        value: "부산광역시",
        label: "부산광역시"
    },
    {
        value: "대구광역시",
        label: "대구광역시"
    },
    {
        value: "인천광역시",
        label: "인천광역시"
    },
    {
        value: "광주광역시",
        label: "광주광역시"
    },
    {
        value: "대전광역시",
        label: "대전광역시"
    },
    {
        value: "울산광역시",
        label: "울산광역시"
    },
    {
        value: "세종특별자치시",
        label: "세종특별자치시"
    },
    {
        value: "수원시",
        label: "수원시"
    },
    {
        value: "고양시",
        label: "고양시"
    },
    {
        value: "용인시",
        label: "용인시"
    },
    {
        value: "성남시",
        label: "성남시"
    },
    {
        value: "부천시",
        label: "부천시"
    },
    {
        value: "안산시",
        label: "안산시"
    },
    {
        value: "화성시",
        label: "화성시"
    },
    {
        value: "남양주시",
        label: "남양주시"
    },
    {
        value: "안양시",
        label: "안양시"
    },
    {
        value: "평택시",
        label: "평택시"
    },
    {
        value: "의정부시",
        label: "의정부시"
    },
    {
        value: "파주시",
        label: "파주시"
    },
    {
        value: "시흥시",
        label: "시흥시"
    },
    {
        value: "김포시",
        label: "김포시"
    },
    {
        value: "광명시",
        label: "광명시"
    },
    {
        value: "광주시(경기)",
        label: "광주시(경기)"
    },
    {
        value: "군포시",
        label: "군포시"
    },
    {
        value: "이천시",
        label: "이천시"
    },
    {
        value: "오산시",
        label: "오산시"
    },
    {
        value: "하남시",
        label: "하남시"
    },
    {
        value: "양주시",
        label: "양주시"
    },
    {
        value: "구리시",
        label: "구리시"
    },
    {
        value: "안성시",
        label: "안성시"
    },
    {
        value: "포천시",
        label: "포천시"
    },
    {
        value: "의왕시",
        label: "의왕시"
    },
    {
        value: "여주시",
        label: "여주시"
    },
    {
        value: "동두천시",
        label: "동두천시"
    },
    {
        value: "과천시",
        label: "과천시"
    },
    {
        value: "가평군",
        label: "가평군"
    },
    {
        value: "양평군",
        label: "양평군"
    },
    {
        value: "연천군",
        label: "연천군"
    },
    {
        value: "춘천시",
        label: "춘천시"
    },
    {
        value: "원주시",
        label: "원주시"
    },
    {
        value: "강릉시",
        label: "강릉시"
    },
    {
        value: "동해시",
        label: "동해시"
    },
    {
        value: "태백시",
        label: "태백시"
    },
    {
        value: "속초시",
        label: "속초시"
    },
    {
        value: "삼척시",
        label: "삼척시"
    },
    {
        value: "홍천군",
        label: "홍천군"
    },
    {
        value: "횡성군",
        label: "횡성군"
    },
    {
        value: "영월군",
        label: "영월군"
    },
    {
        value: "평창군",
        label: "평창군"
    },
    {
        value: "정선군",
        label: "정선군"
    },
    {
        value: "철원군",
        label: "철원군"
    },
    {
        value: "화천군",
        label: "화천군"
    },
    {
        value: "양구군",
        label: "양구군"
    },
    {
        value: "인제군",
        label: "인제군"
    },
    {
        value: "고성군(강원)",
        label: "고성군(강원)"
    },
    {
        value: "양양군",
        label: "양양군"
    },
    {
        value: "청주시",
        label: "청주시"
    },
    {
        value: "충주시",
        label: "충주시"
    },
    {
        value: "제천시",
        label: "제천시"
    },
    {
        value: "보은군",
        label: "보은군"
    },
    {
        value: "옥천군",
        label: "옥천군"
    },
    {
        value: "영동군",
        label: "영동군"
    },
    {
        value: "증평군",
        label: "증평군"
    },
    {
        value: "진천군",
        label: "진천군"
    },
    {
        value: "괴산군",
        label: "괴산군"
    },
    {
        value: "음성군",
        label: "음성군"
    },
    {
        value: "단양군",
        label: "단양군"
    },
    {
        value: "천안시",
        label: "천안시"
    },
    {
        value: "공주시",
        label: "공주시"
    },
    {
        value: "보령시",
        label: "보령시"
    },
    {
        value: "아산시",
        label: "아산시"
    },
    {
        value: "서산시",
        label: "서산시"
    },
    {
        value: "논산시",
        label: "논산시"
    },
    {
        value: "계룡시",
        label: "계룡시"
    },
    {
        value: "당진시",
        label: "당진시"
    },
    {
        value: "금산군",
        label: "금산군"
    },
    {
        value: "부여군",
        label: "부여군"
    },
    {
        value: "서천군",
        label: "서천군"
    },
    {
        value: "청양군",
        label: "청양군"
    },
    {
        value: "홍성군",
        label: "홍성군"
    },
    {
        value: "예산군",
        label: "예산군"
    },
    {
        value: "태안군",
        label: "태안군"
    },
    {
        value: "전주시",
        label: "전주시"
    },
    {
        value: "군산시",
        label: "군산시"
    },
    {
        value: "익산시",
        label: "익산시"
    },
    {
        value: "정읍시",
        label: "정읍시"
    },
    {
        value: "남원시",
        label: "남원시"
    },
    {
        value: "김제시",
        label: "김제시"
    },
    {
        value: "완주군",
        label: "완주군"
    },
    {
        value: "진안군",
        label: "진안군"
    },
    {
        value: "무주군",
        label: "무주군"
    },
    {
        value: "장수군",
        label: "장수군"
    },
    {
        value: "임실군",
        label: "임실군"
    },
    {
        value: "순창군",
        label: "순창군"
    },
    {
        value: "고창군",
        label: "고창군"
    },
    {
        value: "부안군",
        label: "부안군"
    },
    {
        value: "목포시",
        label: "목포시"
    },
    {
        value: "여수시",
        label: "여수시"
    },
    {
        value: "순천시",
        label: "순천시"
    },
    {
        value: "나주시",
        label: "나주시"
    },
    {
        value: "광양시",
        label: "광양시"
    },
    {
        value: "담양군",
        label: "담양군"
    },
    {
        value: "곡성군",
        label: "곡성군"
    },
    {
        value: "구례군",
        label: "구례군"
    },
    {
        value: "고흥군",
        label: "고흥군"
    },
    {
        value: "보성군",
        label: "보성군"
    },
    {
        value: "화순군",
        label: "화순군"
    },
    {
        value: "장흥군",
        label: "장흥군"
    },
    {
        value: "강진군",
        label: "강진군"
    },
    {
        value: "해남군",
        label: "해남군"
    },
    {
        value: "영암군",
        label: "영암군"
    },
    {
        value: "무안군",
        label: "무안군"
    },
    {
        value: "함평군",
        label: "함평군"
    },
    {
        value: "영광군",
        label: "영광군"
    },
    {
        value: "장성군",
        label: "장성군"
    },
    {
        value: "완도군",
        label: "완도군"
    },
    {
        value: "진도군",
        label: "진도군"
    },
    {
        value: "신안군",
        label: "신안군"
    },
    {
        value: "포항시",
        label: "포항시"
    },
    {
        value: "경주시",
        label: "경주시"
    },
    {
        value: "김천시",
        label: "김천시"
    },
    {
        value: "안동시",
        label: "안동시"
    },
    {
        value: "구미시",
        label: "구미시"
    },
    {
        value: "영주시",
        label: "영주시"
    },
    {
        value: "영천시",
        label: "영천시"
    },
    {
        value: "상주시",
        label: "상주시"
    },
    {
        value: "문경시",
        label: "문경시"
    },
    {
        value: "경산시",
        label: "경산시"
    },
    {
        value: "의성군",
        label: "의성군"
    },
    {
        value: "청송군",
        label: "청송군"
    },
    {
        value: "영양군",
        label: "영양군"
    },
    {
        value: "영덕군",
        label: "영덕군"
    },
    {
        value: "청도군",
        label: "청도군"
    },
    {
        value: "고령군",
        label: "고령군"
    },
    {
        value: "성주군",
        label: "성주군"
    },
    {
        value: "칠곡군",
        label: "칠곡군"
    },
    {
        value: "예천군",
        label: "예천군"
    },
    {
        value: "봉화군",
        label: "봉화군"
    },
    {
        value: "울진군",
        label: "울진군"
    },
    {
        value: "울릉군",
        label: "울릉군"
    },
    {
        value: "독도",
        label: "독도"
    },
    {
        value: "창원시",
        label: "창원시"
    },
    {
        value: "진주시",
        label: "진주시"
    },
    {
        value: "통영시",
        label: "통영시"
    },
    {
        value: "사천시",
        label: "사천시"
    },
    {
        value: "김해시",
        label: "김해시"
    },
    {
        value: "밀양시",
        label: "밀양시"
    },
    {
        value: "거제시",
        label: "거제시"
    },
    {
        value: "양산시",
        label: "양산시"
    },
    {
        value: "의령군",
        label: "의령군"
    },
    {
        value: "함안군",
        label: "함안군"
    },
    {
        value: "창녕군",
        label: "창녕군"
    },
    {
        value: "고성군(경남)",
        label: "고성군(경남)"
    },
    {
        value: "남해군",
        label: "남해군"
    },
    {
        value: "하동군",
        label: "하동군"
    },
    {
        value: "산청군",
        label: "산청군"
    },
    {
        value: "함양군",
        label: "함양군"
    },
    {
        value: "거창군",
        label: "거창군"
    },
    {
        value: "합천군",
        label: "합천군"
    },
    {
        value: "제주시",
        label: "제주시"
    },
    {
        value: "서귀포시",
        label: "서귀포시"
    },
    {
        value: "기장군",
        label: "기장군"
    },
    {
        value: "달성군",
        label: "달성군"
    },
    {
        value: "군위군",
        label: "군위군"
    },
    {
        value: "울주군",
        label: "울주군"
    },
    {
        value: "강화군",
        label: "강화군"
    },
    {
        value: "옹진군",
        label: "옹진군"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/model/saju-calendar/model.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SAJU_CALENDAR_TYPE_OPTIONS",
    ()=>SAJU_CALENDAR_TYPE_OPTIONS
]);
const SAJU_CALENDAR_TYPE_OPTIONS = [
    {
        value: "SOLAR",
        label: "양력"
    },
    {
        value: "LUNAR",
        label: "음력"
    },
    {
        value: "LUNAR-LEAP",
        label: "음력 (윤달)"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/model/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "birthTimeOptions",
    ()=>birthTimeOptions,
    "birthYearOptions",
    ()=>birthYearOptions,
    "calendarTypeOptions",
    ()=>calendarTypeOptions,
    "cityOptions",
    ()=>cityOptions,
    "defaultFormValues",
    ()=>defaultFormValues,
    "defaultTouchedSteps",
    ()=>defaultTouchedSteps,
    "genderOptions",
    ()=>genderOptions,
    "timeUnknownOptions",
    ()=>timeUnknownOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$date$2d$time$2d$options$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/model/date-time-options/model.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$city$2d$options$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/model/city-options/model.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$saju$2d$calendar$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/model/saju-calendar/model.ts [app-client] (ecmascript)");
;
;
;
const defaultFormValues = {
    birthYear: "2005",
    birthDate: "",
    city: "",
    calendarType: "SOLAR",
    birthTime: "",
    gender: "",
    timeUnknown: "no"
};
const defaultTouchedSteps = {
    birthDate: false,
    birthTime: false,
    gender: false
};
const birthYearOptions = Array.from({
    length: 100
}, (_, index)=>2005 - index);
const cityOptions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$city$2d$options$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CITY_OPTIONS"];
const birthTimeOptions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$date$2d$time$2d$options$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BIRTH_TIME_OPTIONS"];
const calendarTypeOptions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$saju$2d$calendar$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAJU_CALENDAR_TYPE_OPTIONS"];
const genderOptions = [
    {
        value: "",
        label: "성별 선택"
    },
    {
        value: "FEMALE",
        label: "여성"
    },
    {
        value: "MALE",
        label: "남성"
    }
];
const timeUnknownOptions = [
    {
        value: "no",
        label: "아니오"
    },
    {
        value: "yes",
        label: "예"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/model/zodiac/model.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ZODIAC_LIST",
    ()=>ZODIAC_LIST
]);
const ZODIAC_LIST = [
    {
        key: "rat",
        emoji: "🐭",
        name: "쥐",
        hanja: "子"
    },
    {
        key: "ox",
        emoji: "🐮",
        name: "소",
        hanja: "丑"
    },
    {
        key: "tiger",
        emoji: "🐯",
        name: "호랑이",
        hanja: "寅"
    },
    {
        key: "rabbit",
        emoji: "🐰",
        name: "토끼",
        hanja: "卯"
    },
    {
        key: "dragon",
        emoji: "🐲",
        name: "용",
        hanja: "辰"
    },
    {
        key: "snake",
        emoji: "🐍",
        name: "뱀",
        hanja: "巳"
    },
    {
        key: "horse",
        emoji: "🐴",
        name: "말",
        hanja: "午"
    },
    {
        key: "goat",
        emoji: "🐐",
        name: "양",
        hanja: "未"
    },
    {
        key: "monkey",
        emoji: "🐵",
        name: "원숭이",
        hanja: "申"
    },
    {
        key: "rooster",
        emoji: "🐔",
        name: "닭",
        hanja: "酉"
    },
    {
        key: "dog",
        emoji: "🐶",
        name: "개",
        hanja: "戌"
    },
    {
        key: "pig",
        emoji: "🐷",
        name: "돼지",
        hanja: "亥"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/utils/BirthDate.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isValidBirthMonthDay",
    ()=>isValidBirthMonthDay,
    "parseBackendBirthDateParts",
    ()=>parseBackendBirthDateParts,
    "parseBirthMonthDay",
    ()=>parseBirthMonthDay,
    "toBackendBirthDate",
    ()=>toBackendBirthDate
]);
function parseBirthMonthDay(value) {
    const compact = value.replace(/\s/g, "");
    const match = compact.match(/^(\d{1,2})[\/.-]?(\d{1,2})$/);
    if (!match) {
        return null;
    }
    const month = Number(match[1]);
    const day = Number(match[2]);
    if (month < 1 || month > 12 || day < 1 || day > 31) {
        return null;
    }
    return {
        month,
        day
    };
}
function isValidBirthMonthDay(value) {
    return parseBirthMonthDay(value) !== null;
}
function toBackendBirthDate(birthYear, birthDate) {
    const trimmedYear = birthYear.trim();
    const monthDay = parseBirthMonthDay(birthDate);
    if (!/^\d{4}$/.test(trimmedYear) || !monthDay) {
        return null;
    }
    return `${trimmedYear}-${String(monthDay.month).padStart(2, "0")}-${String(monthDay.day).padStart(2, "0")}`;
}
function parseBackendBirthDateParts(value) {
    if (!value) {
        return {
            year: "",
            month: "",
            day: ""
        };
    }
    const [year, month, day] = value.split("-");
    return {
        year: year ?? "",
        month: month ? String(Number(month)) : "",
        day: day ? String(Number(day)) : ""
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/model/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getFirstIncompleteFieldMessage",
    ()=>getFirstIncompleteFieldMessage,
    "getHighlightedZodiac",
    ()=>getHighlightedZodiac,
    "getHighlightedZodiacIndex",
    ()=>getHighlightedZodiacIndex,
    "getStepCompletionState",
    ()=>getStepCompletionState,
    "getStepStates",
    ()=>getStepStates
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$zodiac$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/model/zodiac/model.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$BirthDate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/utils/BirthDate.ts [app-client] (ecmascript)");
;
;
function getHighlightedZodiacIndex(birthYear, birthDate) {
    const year = Number(birthYear);
    const monthDay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$BirthDate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseBirthMonthDay"])(birthDate);
    if (!Number.isInteger(year) || !monthDay) {
        return null;
    }
    // 입춘(2/4) 이전 출생자는 전년도 띠 기준으로 본다.
    const zodiacYear = monthDay.month < 2 || monthDay.month === 2 && monthDay.day < 4 ? year - 1 : year;
    return ((zodiacYear - 2008) % 12 + 12) % 12;
}
function getHighlightedZodiac(highlightedZodiacIndex) {
    return highlightedZodiacIndex !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$zodiac$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZODIAC_LIST"][highlightedZodiacIndex] : null;
}
function getStepCompletionState(formValues) {
    const isBirthDateStepComplete = formValues.birthYear !== "" && formValues.city !== "" && formValues.calendarType !== "" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$BirthDate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidBirthMonthDay"])(formValues.birthDate.trim());
    // 출생 시간은 선택 입력(옵션)으로 처리한다.
    const isBirthTimeStepComplete = true;
    const isGenderStepComplete = formValues.gender !== "";
    return {
        isBirthDateStepComplete,
        isBirthTimeStepComplete,
        isGenderStepComplete,
        isAllComplete: isBirthDateStepComplete && isBirthTimeStepComplete && isGenderStepComplete
    };
}
function getFirstIncompleteFieldMessage(formValues) {
    if (formValues.birthYear.trim() === "") {
        return {
            title: "출생 연도를 선택해 주세요",
            description: "출생 연도 입력란을 먼저 채워 주세요."
        };
    }
    const birthDate = formValues.birthDate.trim();
    if (birthDate === "") {
        return {
            title: "출생 월/일을 입력해 주세요",
            description: "출생 월/일 입력란을 채워 주세요. 예: 03 / 14"
        };
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$utils$2f$BirthDate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidBirthMonthDay"])(birthDate)) {
        return {
            title: "출생 월/일 형식을 확인해 주세요",
            description: "예: 03 / 14 또는 3/14 형식으로 입력해 주세요."
        };
    }
    if (formValues.city.trim() === "") {
        return {
            title: "출생 도시를 선택해 주세요",
            description: "사주 계산에 사용할 출생 지역을 선택해 주세요."
        };
    }
    if (formValues.calendarType.trim() === "") {
        return {
            title: "양력/음력을 선택해 주세요",
            description: "출생 월/일 기준인 양력 또는 음력을 선택해 주세요."
        };
    }
    if (formValues.gender.trim() === "") {
        return {
            title: "성별을 선택해 주세요",
            description: "성별 입력란을 선택하면 다음 단계로 진행됩니다."
        };
    }
    return {
        title: "4단계 입력을 완료해 주세요",
        description: "모든 항목을 채우면 오늘의 기운 보기가 가능합니다."
    };
}
function getStepStates(steps, touchedSteps, formValues) {
    const { isBirthDateStepComplete, isBirthTimeStepComplete, isGenderStepComplete, isAllComplete } = getStepCompletionState(formValues);
    // step 활성화 규칙은 렌더링과 분리해서 여기서만 관리한다.
    return steps.map((step, index)=>{
        if (index === 0) {
            return {
                ...step,
                active: touchedSteps.birthDate && isBirthDateStepComplete
            };
        }
        if (index === 1) {
            return {
                ...step,
                active: touchedSteps.birthTime && isBirthTimeStepComplete
            };
        }
        if (index === 2) {
            return {
                ...step,
                active: touchedSteps.gender && isGenderStepComplete
            };
        }
        return {
            ...step,
            active: isAllComplete
        };
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/hooks/useSajuInputForm.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSajuInputForm",
    ()=>useSajuInputForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/hooks/useSajuHooks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/model/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/model/utils.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function useSajuInputForm({ steps }) {
    _s();
    const [formValues, setFormValues] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultFormValues"]);
    const [touchedSteps, setTouchedSteps] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultTouchedSteps"]);
    const { handleSubmitSaju } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuHooks"])();
    const highlightedZodiacIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHighlightedZodiacIndex"])(formValues.birthYear, formValues.birthDate);
    const highlightedZodiac = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHighlightedZodiac"])(highlightedZodiacIndex);
    const { isAllComplete } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStepCompletionState"])(formValues);
    const stepStates = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStepStates"])(steps, touchedSteps, formValues);
    const updateField = (field, value)=>{
        setFormValues((prev)=>({
                ...prev,
                [field]: value
            }));
    };
    const touchStep = (step)=>{
        setTouchedSteps((prev)=>({
                ...prev,
                [step]: true
            }));
    };
    return {
        formValues,
        stepStates,
        highlightedZodiac,
        highlightedZodiacIndex,
        isFormComplete: isAllComplete,
        updateField,
        touchStep,
        submitSaju: ()=>handleSubmitSaju(formValues)
    };
}
_s(useSajuInputForm, "u7vGcV3T0PVyCpMlrgPyTh2J3Y4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuHooks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuHooks"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/ui/openmoji-img.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OpenmojiImg",
    ()=>OpenmojiImg
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function emojiToHex(emoji) {
    const codePoint = emoji.codePointAt(0);
    return codePoint ? codePoint.toString(16).toUpperCase() : "";
}
function OpenmojiImg({ emoji, size = 40, alt = "" }) {
    const hex = emojiToHex(emoji);
    const src = `https://openmoji.org/data/black/svg/${hex}.svg`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        src: src,
        alt: alt || emoji,
        width: size,
        height: size,
        style: {
            width: size,
            height: size
        }
    }, void 0, false, {
        fileName: "[project]/src/shared/ui/openmoji-img.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = OpenmojiImg;
var _c;
__turbopack_context__.k.register(_c, "OpenmojiImg");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ZodiacList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$openmoji$2d$img$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/openmoji-img.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$zodiac$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/model/zodiac/model.ts [app-client] (ecmascript)");
"use client";
;
;
;
function ZodiacList({ highlightedIndex = null }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mb-3 text-xs font-bold uppercase tracking-[0.16em] text-sketch-muted",
                children: "12 간지 동물"
            }, void 0, false, {
                fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$model$2f$zodiac$2f$model$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZODIAC_LIST"].map((z, index)=>{
                    const isActive = highlightedIndex === index;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `relative overflow-hidden border-2 p-3 text-center transition-all duration-200 ${isActive ? "border-black bg-sketch-paper" : "border-black/20 bg-white"}`,
                        style: isActive ? {
                            boxShadow: "4px 4px 0 #000"
                        } : {
                            boxShadow: "2px 2px 0 rgba(0,0,0,0.08)"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative z-10 flex flex-col items-center gap-1.5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid h-[48px] w-[48px] place-items-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$openmoji$2d$img$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OpenmojiImg"], {
                                            emoji: z.emoji,
                                            size: 40,
                                            alt: z.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                                            lineNumber: 38,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                                        lineNumber: 37,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        className: `text-xs font-semibold ${isActive ? "text-sketch-ink" : "text-sketch-ink"}`,
                                        children: z.name
                                    }, void 0, false, {
                                        fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                                        lineNumber: 40,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[11px] text-sketch-subtle",
                                        children: z.hanja
                                    }, void 0, false, {
                                        fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                                        lineNumber: 45,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                                lineNumber: 36,
                                columnNumber: 15
                            }, this),
                            isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "absolute right-1.5 top-1.5 border-2 border-black bg-black px-1.5 py-0.5 text-[10px] font-bold text-white",
                                children: "선택됨"
                            }, void 0, false, {
                                fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                                lineNumber: 51,
                                columnNumber: 17
                            }, this)
                        ]
                    }, z.name, true, {
                        fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                        lineNumber: 23,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = ZodiacList;
var _c;
__turbopack_context__.k.register(_c, "ZodiacList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/hooks/useSajuValidationToast.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSajuValidationToast",
    ()=>useSajuValidationToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/model/utils.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const defaultValidationToastMessage = {
    title: "4단계 입력을 완료해 주세요",
    description: "모든 항목을 채우면 오늘의 기운 보기가 가능합니다."
};
function useSajuValidationToast(formValues) {
    _s();
    const [isValidationToastOpen, setValidationToastOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [validationToastMessage, setValidationToastMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultValidationToastMessage);
    const showValidationToast = ()=>{
        setValidationToastMessage((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirstIncompleteFieldMessage"])(formValues));
        setValidationToastOpen(false);
        requestAnimationFrame(()=>{
            setValidationToastOpen(true);
        });
    };
    return {
        isValidationToastOpen,
        setValidationToastOpen,
        validationToastMessage,
        showValidationToast
    };
}
_s(useSajuValidationToast, "IDIn7VCA/ZqdM31CCMXqmcNM1bc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/step/step.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InputStep
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
// 스텝별 색상 — active(진함) / inactive(연함)
const STEP_COLORS = [
    {
        activeBg: "#FEF3C7",
        activeBorder: "#D97706",
        inactiveBg: "#FFFBEB",
        inactiveBorder: "#FCD34D"
    },
    {
        activeBg: "#DBEAFE",
        activeBorder: "#2563EB",
        inactiveBg: "#EFF6FF",
        inactiveBorder: "#93C5FD"
    },
    {
        activeBg: "#D1FAE5",
        activeBorder: "#059669",
        inactiveBg: "#ECFDF5",
        inactiveBorder: "#6EE7B7"
    },
    {
        activeBg: "#FCE7F3",
        activeBorder: "#DB2777",
        inactiveBg: "#FDF2F8",
        inactiveBorder: "#F9A8D4"
    }
];
function InputStep({ steps }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-[18px] flex flex-wrap items-center gap-2",
        children: steps.map((step, i)=>{
            const color = STEP_COLORS[i] ?? STEP_COLORS[0];
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "inline-flex items-center gap-1.5 border-2 px-3 py-1 text-xs font-bold transition-all",
                style: step.active ? {
                    backgroundColor: color.activeBg,
                    borderColor: color.activeBorder,
                    color: color.activeBorder,
                    boxShadow: `2px 2px 0 ${color.activeBorder}`
                } : {
                    backgroundColor: color.inactiveBg,
                    borderColor: color.inactiveBorder,
                    color: color.inactiveBorder
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex h-3.5 w-3.5 shrink-0 items-center justify-center border text-[9px] font-black",
                        style: step.active ? {
                            borderColor: color.activeBorder,
                            color: color.activeBorder
                        } : {
                            borderColor: color.inactiveBorder,
                            color: color.inactiveBorder
                        },
                        children: i + 1
                    }, void 0, false, {
                        fileName: "[project]/src/features/saju-input/step/step.tsx",
                        lineNumber: 42,
                        columnNumber: 13
                    }, this),
                    step.label
                ]
            }, step.label, true, {
                fileName: "[project]/src/features/saju-input/step/step.tsx",
                lineNumber: 24,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/src/features/saju-input/step/step.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c = InputStep;
var _c;
__turbopack_context__.k.register(_c, "InputStep");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SajuInputFields",
    ()=>SajuInputFields
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-toast/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$domain$2f$saju$2f$guid$2d$card$2f$12zodiac$2f$12zodiac$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/domain/saju/guid-card/12zodiac/12zodiac.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuValidationToast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/hooks/useSajuValidationToast.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$openmoji$2d$img$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/ui/openmoji-img.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/model/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$step$2f$step$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/step/step.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const fieldClassName = "sketch-input w-full cursor-pointer appearance-none py-3.5";
function SajuInputFields({ formValues, stepStates, highlightedZodiac, highlightedZodiacIndex, onChangeField, onTouchStep, isFormComplete, onSubmitSaju }) {
    _s();
    const { isValidationToastOpen, setValidationToastOpen, validationToastMessage, showValidationToast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuValidationToast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuValidationToast"])(formValues);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Provider"], {
        swipeDirection: "right",
        duration: 2200,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$step$2f$step$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                steps: stepStates
            }, void 0, false, {
                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                className: "mt-5",
                onSubmit: (event)=>{
                    event.preventDefault();
                    if (!isFormComplete) {
                        showValidationToast();
                        return;
                    }
                    onSubmitSaju();
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-black/60",
                                        children: "출생 연도"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 73,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: formValues.birthYear,
                                        // 여기서 onChangeField("birthYear", ...) 를 호출하면
                                        // 실제 실행은 sagu-input-fields.container.tsx 의 updateField 에서 된다.
                                        onChange: (event)=>onChangeField("birthYear", event.target.value),
                                        onBlur: ()=>onTouchStep("birthDate"),
                                        className: fieldClassName,
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["birthYearOptions"].map((year)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: year,
                                                children: year
                                            }, year, false, {
                                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                                lineNumber: 85,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 74,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-black/60",
                                        children: "출생 월 / 일"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 93,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "03 / 14",
                                        value: formValues.birthDate,
                                        // 여기서 onChangeField("birthDate", ...) 를 호출하면
                                        // container가 다시 렌더되고 getHighlightedZodiacIndex / getStepStates 가 다시 호출된다.
                                        onChange: (event)=>onChangeField("birthDate", event.target.value),
                                        onBlur: ()=>onTouchStep("birthDate"),
                                        className: fieldClassName
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 96,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-black/60",
                                        children: "양력 / 음력"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 111,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: formValues.calendarType,
                                        onChange: (event)=>onChangeField("calendarType", event.target.value),
                                        onBlur: ()=>onTouchStep("birthDate"),
                                        className: fieldClassName,
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calendarTypeOptions"].map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: option.value,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                                lineNumber: 121,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 112,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 110,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-black/60",
                                        children: "출생 도시"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 129,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: formValues.city,
                                        onChange: (event)=>onChangeField("city", event.target.value),
                                        onBlur: ()=>onTouchStep("birthDate"),
                                        className: fieldClassName,
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cityOptions"].map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: option.value,
                                                children: option.label
                                            }, option.value || "empty", false, {
                                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                                lineNumber: 137,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 130,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 128,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-black/60",
                                        children: "출생 시간"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 145,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: formValues.birthTime,
                                        onChange: (event)=>onChangeField("birthTime", event.target.value),
                                        onBlur: ()=>onTouchStep("birthTime"),
                                        disabled: formValues.timeUnknown === "yes",
                                        className: fieldClassName,
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["birthTimeOptions"].map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: option.value,
                                                children: option.label
                                            }, option.value || "empty", false, {
                                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                                lineNumber: 156,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 146,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex flex-col gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-black/60",
                                        children: "성별"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 164,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: formValues.gender,
                                        onChange: (event)=>onChangeField("gender", event.target.value),
                                        onBlur: ()=>onTouchStep("gender"),
                                        className: fieldClassName,
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$model$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["genderOptions"].map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: option.value,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                                lineNumber: 172,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 165,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 163,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "sketch-border mt-4 flex items-center gap-3.5 p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid h-[60px] w-[60px] shrink-0 place-items-center rounded-sm border-2 border-black",
                                style: {
                                    boxShadow: "2px 2px 0 #000"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$ui$2f$openmoji$2d$img$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OpenmojiImg"], {
                                    emoji: highlightedZodiac?.emoji ?? "🌙",
                                    size: 36,
                                    alt: highlightedZodiac?.name ?? "수정구슬"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                    lineNumber: 207,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 203,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        className: "text-sm font-bold text-black",
                                        children: highlightedZodiac !== null ? `${formValues.birthYear}년생 · ${highlightedZodiac.name}띠` : "출생일을 입력하면 띠가 자동 선택됩니다"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 214,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-xs text-black/50",
                                        children: highlightedZodiac !== null ? "12간지 카드에서 자동으로 강조 표시됩니다." : "예: 03 / 14 형식으로 입력해보세요."
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                        lineNumber: 219,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 213,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                        lineNumber: 202,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4 flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "btn-saju btn-saju-secondary",
                                children: "이전"
                            }, void 0, false, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 227,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: "btn-saju btn-saju-primary flex-1",
                                children: "오늘의 기운 보기"
                            }, void 0, false, {
                                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                                lineNumber: 230,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                        lineNumber: 226,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$domain$2f$saju$2f$guid$2d$card$2f$12zodiac$2f$12zodiac$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                highlightedIndex: highlightedZodiacIndex
            }, void 0, false, {
                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                lineNumber: 236,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
                open: isValidationToastOpen,
                onOpenChange: setValidationToastOpen,
                className: "fixed left-1/2 top-4 z-50 w-[calc(100%-2rem)] max-w-[28rem] -translate-x-1/2 rounded-sm border-2 border-black bg-white p-4 shadow-[4px_4px_0_0_#000]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"], {
                        className: "text-sm font-bold text-black",
                        children: validationToastMessage.title
                    }, void 0, false, {
                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                        lineNumber: 242,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"], {
                        className: "mt-1 text-xs text-black/65",
                        children: validationToastMessage.description
                    }, void 0, false, {
                        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                        lineNumber: 245,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                lineNumber: 237,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"], {
                className: "pointer-events-none fixed inset-0 z-50"
            }, void 0, false, {
                fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
                lineNumber: 249,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
}
_s(SajuInputFields, "oHrGweecQxkqBi3ryt7MJL54KBw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuValidationToast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuValidationToast"]
    ];
});
_c = SajuInputFields;
var _c;
__turbopack_context__.k.register(_c, "SajuInputFields");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/saju-input/form/client/saju-input-fields.container.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SajuInputFieldsContainer",
    ()=>SajuInputFieldsContainer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuInputForm$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/hooks/useSajuInputForm.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$form$2f$client$2f$saju$2d$input$2d$fields$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/saju-input/form/client/saju-input-fields.client.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function SajuInputFieldsContainer({ steps }) {
    _s();
    const { formValues, stepStates, highlightedZodiac, highlightedZodiacIndex, isFormComplete, updateField, touchStep, submitSaju } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuInputForm$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuInputForm"])({
        steps
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$form$2f$client$2f$saju$2d$input$2d$fields$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SajuInputFields"], {
        formValues: formValues,
        stepStates: stepStates,
        highlightedZodiac: highlightedZodiac,
        highlightedZodiacIndex: highlightedZodiacIndex,
        onChangeField: updateField,
        onTouchStep: touchStep,
        isFormComplete: isFormComplete,
        onSubmitSaju: submitSaju
    }, void 0, false, {
        fileName: "[project]/src/features/saju-input/form/client/saju-input-fields.container.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_s(SajuInputFieldsContainer, "wzlhor/egFUSjSJmz3OqpyJDx24=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$saju$2d$input$2f$hooks$2f$useSajuInputForm$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSajuInputForm"]
    ];
});
_c = SajuInputFieldsContainer;
var _c;
__turbopack_context__.k.register(_c, "SajuInputFieldsContainer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0png2m.._.js.map