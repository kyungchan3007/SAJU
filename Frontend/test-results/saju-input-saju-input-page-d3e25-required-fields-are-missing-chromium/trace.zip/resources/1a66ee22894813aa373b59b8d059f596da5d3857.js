(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0f_fvoy._.css","static/chunks/node_modules_0fh~-uy._.js","static/chunks/src_0-ta-_o._.js"],
    source: "dynamic"
});
