(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0a74cwr._.js","static/chunks/node_modules_@tanstack_03_dpvc._.js"],
    source: "dynamic"
});
